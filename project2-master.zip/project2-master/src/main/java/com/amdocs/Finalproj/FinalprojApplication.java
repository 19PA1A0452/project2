package com.amdocs.Finalproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalprojApplication.class, args);
	}

}
